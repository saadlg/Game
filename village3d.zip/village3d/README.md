# القرية 3D — مشروع Android

اللعبة داخل WebView بملء الشاشة (أفقي)، والملف الرئيسي: `app/src/main/assets/index.html`.

## بناء APK من الهاتف (بدون حاسوب)
1. أنشئ مستودعاً جديداً على github.com وارفع محتويات هذا المجلد كما هي (مع المجلد المخفي `.github`).
2. افتح تبويب **Actions** ثم **Build APK** ثم **Run workflow**.
3. بعد دقائق افتح التشغيل الناجح ونزّل **Village3D-apk** من قسم Artifacts، فك الضغط وثبّت الملف `.apk`.

## بناء APK من Android Studio
افتح المجلد ثم Build ▸ Build APK(s).

## ملاحظة
اللعبة تحمّل مكتبة three.js من الإنترنت (cdnjs)، لذلك تحتاج اتصالاً عند أول تشغيل.
